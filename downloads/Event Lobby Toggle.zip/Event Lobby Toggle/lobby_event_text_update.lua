Hooks:PostHook(ContractBoxGui, "init", "ELT_lobby_mutators_category", function(self, ...)
	self._elt_lobby_mutator_category = managers.mutators:get_enabled_active_mutator_category()
end)

function ContractBoxGui:elt_check_update_lobby_mutators_text()
	if alive(self._lobby_mutators_text) then
		self._lobby_mutators_text:set_visible(managers.mutators:are_mutators_enabled())

		local mutator_category = managers.mutators:get_enabled_active_mutator_category()

		if mutator_category ~= self._elt_lobby_mutator_category then
			local mutator_string_id = "menu_" .. mutator_category .. "s_lobby_wait_title"
			self._lobby_mutators_text:set_text(managers.localization:to_upper_text(mutator_string_id))
			self._lobby_mutators_text:set_color(managers.mutators:get_category_text_color(mutator_category))

			self._elt_lobby_mutator_category = mutator_category
		end
	end
end

Hooks:PostHook(ContractBoxGui, "check_update_mutators_tooltip", "ELT_check_update_mutators_tooltip", function(self, ...)
	self:elt_check_update_lobby_mutators_text()
end)

function ContractBoxGui:elt_event_toggled()
	if managers.job:current_contact_data() then
		self:check_update_mutators_tooltip()
	else
		self:elt_check_update_lobby_mutators_text()
	end
end

Hooks:PostHook(ContractBoxGui, "update", "ELT_update_lobby_mutators_text", function(self, t, dt, ...)
	if not managers.job:current_contact_data() then
		self._update_tooltip_t = (self._update_tooltip_t or 1) - dt

		if self._update_tooltip_t < 0 then
			self:elt_check_update_lobby_mutators_text()

			self._update_tooltip_t = 1
		end
	end
end)
