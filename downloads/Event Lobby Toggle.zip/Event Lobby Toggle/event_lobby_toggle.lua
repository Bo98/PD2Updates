Hooks:Add("MenuManagerBuildCustomMenus", "EventLobbyToggle_MenuManagerBuildCustomMenus", function(menu_manager, nodes)
	local lobbymenu = nodes.lobby
	if not lobbymenu then
		return
	end

	local mainmenu = nodes.main
	if not mainmenu then
		return
	end

	local play_event_btn = mainmenu:item("crimenet_event")
	if not play_event_btn then
		-- Event ended (probably)
		return
	end

	local data = {
		type = "CoreMenuItem.Item",
	}
	local enable_event_lobby_btn = lobbymenu:create_item(data, {
		name = "elt_enable_event_lobby_btn",
		text_id = "Enable Event Mode",
		callback = "elt_enable_event_lobby",
		visible_callback = "is_server has_gamemode_event elt_is_not_event elt_is_valid_event_job",
		localize = false
	})
	local disable_event_lobby_btn = lobbymenu:create_item(data, {
		name = "elt_disable_event_lobby_btn",
		text_id = "Disable Event Mode",
		callback = "elt_disable_event_lobby",
		visible_callback = "is_server elt_is_event",
		localize = false
	})

	local pos = 3
	for i, item in pairs(lobbymenu:items()) do
		if item:name() == "edit_game_settings" then
			pos = i + 1
			break
		end
	end

	lobbymenu:insert_item(enable_event_lobby_btn, pos)
	lobbymenu:insert_item(disable_event_lobby_btn, pos)
end)

function MenuCallbackHandler:elt_is_event()
	return managers.mutators:get_enabled_active_mutator_category() == "event"
end

function MenuCallbackHandler:elt_is_not_event()
	return not self:elt_is_event()
end

function MenuCallbackHandler:elt_is_valid_event_job()
	local current_level = managers.job:current_level_id()
	local event_levels = table.map_keys(tweak_data.mutators.piggyrevenge.level_coordinates)

	return not current_level or table.contains(event_levels, current_level)
end

function MenuCallbackHandler:elt_enable_event_lobby()
	managers.mutators:reset_all_mutators()
	managers.perpetual_event:play_event_game()
	self:_update_mutators_info()
	local track_override = managers.mutators:get_track_override("lobby")
	if track_override then
		managers.music:post_event(track_override)
	end

	self:refresh_node()

	if managers.menu_component._contract_gui then
		managers.menu_component._contract_gui:elt_event_toggled()
	end
end

function MenuCallbackHandler:elt_disable_event_lobby()
	if managers.mutators:get_enabled_active_mutator_category() == "event" then
		managers.mutators:reset_all_mutators()
		self:_update_mutators_info()
	end

	managers.music:post_event(managers.music:jukebox_menu_track("mainmenu"))

	self:refresh_node()

	if managers.menu_component._contract_gui then
		managers.menu_component._contract_gui:elt_event_toggled()
	end
end
