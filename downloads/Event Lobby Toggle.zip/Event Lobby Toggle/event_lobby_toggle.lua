Hooks:Add("MenuManagerBuildCustomMenus", "EventLobbyToggle_MenuManagerBuildCustomMenus", function(menu_manager, nodes)
	local lobbymenu = nodes.lobby
	if not lobbymenu then
		return
	end

	local mainmenu = nodes.main
	if not mainmenu then
		return
	end

	local play_event_btn = mainmenu:item("crimenet_event")
	if not play_event_btn or not play_event_btn:visible() then
		-- Event ended (probably)
		return
	end

	local data = {
		type = "CoreMenuItem.Item",
	}
	local enable_event_lobby_btn = lobbymenu:create_item(data, {
		name = "elt_enable_event_lobby_btn",
		text_id = "Enable Event Mode",
		callback = "elt_enable_event_lobby",
		visible_callback = "is_server is_not_event elt_is_valid_event_job",
		localize = false
	})
	local disable_event_lobby_btn = lobbymenu:create_item(data, {
		name = "elt_disable_event_lobby_btn",
		text_id = "Disable Event Mode",
		callback = "elt_disable_event_lobby",
		visible_callback = "is_server is_event",
		localize = false
	})

	local pos = 3
	for i, item in pairs(lobbymenu:items()) do
		if item:name() == "edit_game_settings" then
			pos = i + 1
			break
		end
	end

	lobbymenu:insert_item(enable_event_lobby_btn, pos)
	lobbymenu:insert_item(disable_event_lobby_btn, pos)
end)

function MenuCallbackHandler:elt_is_valid_event_job()
	local current_level = managers.job:current_level_id()
	local event_levels = table.map_keys(tweak_data.mutators.piggybank.level_coordinates)

	return not current_level or table.contains(event_levels, current_level)
end

function MenuCallbackHandler:elt_enable_event_lobby()
	managers.mutators:reset_all_mutators()
	managers.mutators:set_enabled(managers.mutators:get_mutator(MutatorCG22), true)
	managers.mission:set_saved_job_value("cg22_participation", true)
	self:_update_mutators_info()

	self:refresh_node()

	if managers.menu_component._contract_gui then
		managers.menu_component._contract_gui:elt_event_toggled()
	end
end

function MenuCallbackHandler:elt_disable_event_lobby()
	if managers.mutators:get_enabled_active_mutator_category() == "event" then
		managers.mutators:reset_all_mutators()
		self:_update_mutators_info()
	end

	self:refresh_node()

	if managers.menu_component._contract_gui then
		managers.menu_component._contract_gui:elt_event_toggled()
	end
end
