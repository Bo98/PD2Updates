Hooks:PostHook(MutatorsManager, "has_peer_been_notified", "ELT_event_peer_notified", function(self, ...)
	if self:get_enabled_active_mutator_category() == "event" then
		return true
	end
end)

Hooks:PostHook(MutatorsManager, "is_peer_ready", "ELT_event_peer_ready", function(self, ...)
	if self:get_enabled_active_mutator_category() == "event" then
		return true
	end
end)

local orig_on_peer_added = Hooks:GetFunction(MutatorsManager, "on_peer_added")
Hooks:OverrideFunction(MutatorsManager, "on_peer_added", function(self, ...)
	if self:get_enabled_active_mutator_category() == "event" then
		return
	end

	return orig_on_peer_added(self, ...)
end)
