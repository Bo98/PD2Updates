local orig_has_peer_been_notified = MutatorsManager.has_peer_been_notified
function MutatorsManager:has_peer_been_notified(...)
	if self:get_enabled_active_mutator_category() == "event" then
		return true
	end

	orig_has_peer_been_notified(self, ...)
end

local orig_is_peer_ready = MutatorsManager.is_peer_ready
function MutatorsManager:is_peer_ready(...)
	if self:get_enabled_active_mutator_category() == "event" then
		return true
	end

	orig_is_peer_ready(self, ...)
end

local orig_on_peer_added = MutatorsManager.on_peer_added
function MutatorsManager:on_peer_added(...)
	if self:get_enabled_active_mutator_category() == "event" then
		return
	end

	orig_on_peer_added(self, ...)
end
